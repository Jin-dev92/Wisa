Custom_w = {

};

jQuery(function($){

});

$(window).load(function(){
	
});