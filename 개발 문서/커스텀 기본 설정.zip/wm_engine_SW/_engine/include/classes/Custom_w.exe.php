<?php
include_once $engine_dir."/_engine/include/classes/Custom_w.class.php";

// ajax
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
	$result = true;
	$msg = '';

	try{
		switch ($exec){
			case '':
				break;
		}
	} catch (Exception $e){
		$result = false;
		$msg = $e->getMessage();
	}

	echo json_encode(array('result'=>$result, 'msg'=>$msg));
} 
// default
else {
	try{
		switch ($exec){
			case '':
				break;
		}
	} catch (Exception $e){
		msg($e->getMessage(), 'back');
	}
}
exit;