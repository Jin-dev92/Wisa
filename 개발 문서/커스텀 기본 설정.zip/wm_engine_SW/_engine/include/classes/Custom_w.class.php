<?php
if( !defined('_wisa_set_included') ){
	include_once "../../../../_config/set.php";
}
if( !defined('_wisa_lib_included') ){
	include_once $engine_dir."/_engine/include/common.lib.php";
}
if( defined("_set_custom_w") ){
	return;
}

define("_set_custom_w", true);

class Custom_w {
	
}